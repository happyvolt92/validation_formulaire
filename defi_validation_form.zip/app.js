var form = document.querySelector(".form");
var nameForm = document.querySelector("#name-form");
var noteForm = document.querySelector("#note-form");
var editForm = document.querySelector("#edit-form");
var alertContainer = document.querySelector(".alert-container");
var submitBtn = document.querySelector(".submit-btn");
var moyenneBtn = document.querySelector(".moyenne-btn");
var modifierBtn = document.querySelector(".modifier-btn");
var suprimerBtn = document.querySelector(".suprimer-btn");
var alphaBtn = document.querySelector(".alpha-btn");
var croissantBtn = document.querySelector(".croissant-btn");
var elevesSection = document.querySelector(".eleves-section");
var eleves = [];
var letters = "^[a-zA-Z_-]*$";

// ---------------------------------------- SUBMIT
function submitEleve() {
  if (
    nameForm.value[0] == nameForm.value[0].toUpperCase() &&
    nameForm.value.match(letters) &&
    noteForm.value !== "" &&
    noteForm.value >= 0 &&
    noteForm.value <= 20 &&
    eleves.length <= 17
  ) {
    eleves.push({ name: `${nameForm.value}`, note: `${noteForm.value}` });
    var elevesliste = eleves.map(function (eleve) {
      return `<article class="eleve-article">
        <h2 class="name">${eleve.name}</h2>
        <h3>${eleve.note}</h3>
      </article>`;
    });
    elevesSection.innerHTML = elevesliste.join("");
    showMoyenneBtn();
    alertSuccess("Eleve ajouté");
    resetInput();
  } else if (eleves.length == 18) {
    alertDanger("Nombre max d'élèves");
  } else {
    alertDanger("Il faut une majuscule au nom et une note entre 0 et 20ans");
  }
}

submitBtn.addEventListener("click", function (e) {
  e.preventDefault();
  submitEleve();
});

// ---------------------------------------- ERROR CHECK

function errorCheck() {
  if (
    editForm.value[0] == editForm.value[0].toUpperCase() &&
    editForm.value.match(letters) &&
    noteForm.value !== "" &&
    noteForm.value >= 0 &&
    noteForm.value <= 20 &&
    eleves.length <= 17
  ) {
    afficherTableau();
    showMoyenneBtn();
    alertSuccess("Eleve ajouté");
    resetInput();
  } else if (eleves.length == 18) {
    alertDanger("Nombre max d'élèves");
  } else {
    alertDanger("Il faut une majuscule au nom et une note entre 0 et 20ans");
  }
}

// ---------------------------------------- MOYENNE

moyenneBtn.addEventListener("click", function (e) {
  e.preventDefault();
  var total = 0;
  for (var i = 0; i < eleves.length; i++) {
    total += parseInt(eleves[i].note);
  }
  var avg = total / eleves.length;
  console.log(avg);
  if (avg < 8) {
    console.log("peut mieux faire");
  } else if (avg > 8 && avg < 10) {
    console.log("en progres");
  } else if (avg == 10) {
    console.log("tout juste");
  } else if (avg > 10 && avg < 18) {
    console.log("de mieux en mieux");
  } else if (avg > 18 && avg < 20) {
    console.log("waouh!!");
  } else if (avg == 20) {
    console.log("bande de tricheurs");
  }
});

// ---------------------------------------- BOUTON MOYENNE APPARAIT

function showMoyenneBtn() {
  if (eleves.length >= 2) {
    moyenneBtn.classList.remove("display-none");
  }
}

// ---------------------------------------- MODIFIER

function modifierEleve() {
  eleves.splice(
    eleves.findIndex((e) => e.name == nameForm.value),
    1,
    { name: `${editForm.value}`, note: `${noteForm.value}` }
  );
  errorCheck();
}

modifierBtn.addEventListener("click", function (e) {
  e.preventDefault();
  modifierEleve();
});

// ---------------------------------------- SUPPRIMER

function supprimerEleve() {
  eleves.splice(
    eleves.findIndex((e) => e.name == nameForm.value),
    1
  );
  afficherTableau();
}

suprimerBtn.addEventListener("click", function (e) {
  e.preventDefault();
  supprimerEleve();
});

// ---------------------------------------- ALPHABET

function alphaEleves() {
  eleves.sort(function (a, b) {
    if (a.name < b.name) {
      return -1;
    }
    if (a.name > b.name) {
      return 1;
    }
    return 0;
  });
  afficherTableau();
}

alphaBtn.addEventListener("click", function (e) {
  e.preventDefault();
  alphaEleves();
});

// ---------------------------------------- CROISSANT

function croissantEleves() {
  eleves.sort(function (a, b) {
    if (parseInt(a.note) < parseInt(b.note)) {
      return -1;
    }
    if (parseInt(a.note) > parseInt(b.note)) {
      return 1;
    }
    return 0;
  });
  afficherTableau();
}

croissantBtn.addEventListener("click", function (e) {
  e.preventDefault();
  croissantEleves();
});

// ---------------------------------------- RESET INPUT

function resetInput() {
  // nameForm.value = "";
  // editForm.value = "";
  // noteForm.value = "";
  form.reset();
}

// ---------------------------------------- ALERT BOXES

function alertSuccess(text) {
  alertContainer.innerHTML = ` <div class="alert alert-success">${text}</div>`;
  setTimeout(() => {
    alertContainer.innerHTML = ``;
  }, 3000);
}

function alertDanger(text) {
  alertContainer.innerHTML = ` <div class="alert alert-danger">${text}</div>`;
  setTimeout(() => {
    alertContainer.innerHTML = ``;
  }, 3000);
}

// ---------------------------------------- AFFICHER TABLEAU

function afficherTableau() {
  var elevesliste = eleves.map(function (eleve) {
    return `<article class="eleve-article">
         <h2 class="name">${eleve.name}</h2>
         <h3>${eleve.note}</h3>
       </article>`;
  });
  elevesSection.innerHTML = elevesliste.join("");
}
